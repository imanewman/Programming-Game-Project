public interface Animated extends Active {
    public int animationPeriod();
    public Action createAnimationAction(int repeatCount);
}
