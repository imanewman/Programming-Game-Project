import processing.core.PImage;

import java.util.List;

public abstract class AbsEntity extends AbsObject implements Entity {
    private Point position;

    public AbsEntity(String id, Point position,
                      List<PImage> images, int imageIndex) {
        super(id, images, imageIndex);
        this.position = position;
    }

    public Point position() { return position; }

    public void setPosition(Point pos) {
        position = pos;
    }
}
