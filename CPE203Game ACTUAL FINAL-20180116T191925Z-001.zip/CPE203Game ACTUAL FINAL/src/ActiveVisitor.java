public class ActiveVisitor implements EntityVisitor<Boolean> {
    public Boolean visit(Ore ore) { return true; }

    public Boolean visit(OreBlob oreBlob) { return true; }

    public Boolean visit(Blacksmith blacksmith) { return false; }

    public Boolean visit(Obstacle obstacle) { return false; }

    public Boolean visit(MinerNotFull minerNotFull) { return true; }

    public Boolean visit(MinerFull minerFull) { return true; }

    public Boolean visit(Vein vein) { return true; }

    public Boolean visit(Quake quake) { return true; }

    public Boolean visit(Sinkhole sinkhole) { return true; }

    public Boolean visit(Alien alien) { return true; }

    public Boolean visit(RandomCreature randomCreature) { return true; }

    public Boolean visit(Lawnmower lawnmower) { return true; }

}
