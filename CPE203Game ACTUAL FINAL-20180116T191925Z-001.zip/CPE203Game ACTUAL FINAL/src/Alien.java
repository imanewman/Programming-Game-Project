import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class Alien extends AbsMovable {
    public static final String ALIEN_ID = "alien";
    public static final int ALIEN_ACTION_PERIOD = 150;
    public static final int ALIEN_ANIMATION_PERIOD = 150;

    private final int MAX_LIFESPAN = 30;

    private int lifeSpan;
    private boolean spawned;
    private Viewport viewport;

    public Alien(String id, Point position, int actionPeriod, int animationPeriod,
                 List<PImage> images, Viewport viewport) {
        super(id, position, images, 0, actionPeriod, animationPeriod, new AStarPathingStrategy());
        spawned = false;
        this.viewport = viewport;
        lifeSpan = 0;
    }

    public void nextImage() {
        if (!spawned) {
            setImageIndex(imageIndex() + 1);
            if (imageIndex() == 2) spawned = true;
        } else {
            setImageIndex(((imageIndex()) % 2) + 3);
        }
    }

    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        long nextPeriod = actionPeriod() * 3;

        if (spawned) {
            Optional<Entity> target = world.findNearest(position(), MinerNotFull.class);

            if (target.isPresent()) {
                Point tgtPos = target.get().position();

                if (moveTo(world, target.get(), scheduler)) {
                    Entity randomSprite = CreateEntity.createRandomCreature(RandomCreature.RANDOM_CREATURE_ID,
                            tgtPos, RandomCreature.RANDOM_CREATURE_ACTION_PERIOD,
                            RandomCreature.RANDOM_CREATURE_ANIMATION_PERIOD,
                            imageStore.images().get(RandomCreature.RANDOM_CREATURE_ID), 2);

                    world.addEntity(randomSprite);
                    ((Active) randomSprite).scheduleActions(scheduler, world, imageStore);
                }
           }
        }

        if (lifeSpan < MAX_LIFESPAN) {
            lifeSpan++;
            scheduler.scheduleEvent(this,
                    createActivityAction(world, imageStore),
                    nextPeriod);
        } else {
            int rand = (int)(Math.random() * 10);
            Entity sinkhole = CreateEntity.createSinkhole(Sinkhole.SINKHOLE_ID, position(),
                    Sinkhole.SINKHOLE_ACTION_PERIOD, imageStore.images().get(Sinkhole.SINKHOLE_ID),
                    1, viewport);


            world.removeEntity(this);
            scheduler.unscheduleAllEvents(this);

            if (rand > 5) {
                world.addEntity(sinkhole);
                ((Active) sinkhole).scheduleActions(scheduler, world, imageStore);
            } else world.removeEntity(sinkhole);
        }
    }

    public Point nextPos(WorldModel world, Point destPos) {
        if (!destPos.equals(destination())) {
            setDestination(destPos);
            resetGValue();
            resetLastPos();
        }
        List<Point> points = strategy().computePath(position(), destPos, lastPos(), gValue(),
                p -> world.withinBounds(p) && !(world.getOccupant(p).isPresent()),
                (p1, p2) -> PathingStrategy.CARDINAL_NEIGHBORS.apply(p1).anyMatch(p -> p.equals(p2)),
                PathingStrategy.DIAGONAL_CARDINAL_NEIGHBORS);

        if (points.size() > 0)
            return points.get(0);
        else
            return position();
    }

    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        if (position().adjacent(target.position())) {
            world.removeEntity(target);
            scheduler.unscheduleAllEvents(target);
            resetGValue();
            return true;
        } else return super.moveTo(world, target, scheduler);
    }

    public <R> R accept(EntityVisitor<R> visitor) { return visitor.visit(this); }
}
