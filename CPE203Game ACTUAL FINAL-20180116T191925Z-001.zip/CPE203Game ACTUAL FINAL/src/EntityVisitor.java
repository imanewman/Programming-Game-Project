public interface EntityVisitor<R> {
    public R visit(Ore ore);
    public R visit(OreBlob oreBlob);
    public R visit(Blacksmith blacksmith);
    public R visit(Obstacle obstacle);
    public R visit(MinerNotFull minerNotFull);
    public R visit(MinerFull minerFull);
    public R visit(Vein vein);
    public R visit(Quake quake);
    public R visit(Sinkhole sinkhole);
    public R visit(Alien alien);
    public R visit(RandomCreature randomCreature);
    public R visit(Lawnmower lawnmower);
}
