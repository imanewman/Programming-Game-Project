import processing.core.PImage;

import java.util.List;

public abstract class AbsDirectionable extends AbsMovable {
    public static final String UP_DIR = "up";
    public static final String DOWN_DIR = "down";
    public static final String LEFT_DIR = "left";
    public static final String RIGHT_DIR = "right";

    protected final String MINER_ID = "miner";
    protected final int MINER_RESOURCE_LIMIT = 2;
    protected final int MINER_ACTION_PERIOD = 600;
    protected final int MINER_ANIMATION_PERIOD = 600;

    private String direction;

    public AbsDirectionable(String id, Point position, int actionPeriod, int animationPeriod,
                          List<PImage> images) {
        super(id, position, images, 0, actionPeriod, animationPeriod, new AStarPathingStrategy());
        direction = DOWN_DIR;
    }

    public String direction() { return direction; }

    public Point nextPos(WorldModel world, Point destPos) {
        if (!destPos.equals(destination())) {
            setDestination(destPos);
            resetGValue();
            resetLastPos();
        }
        List<Point> points = strategy().computePath(position(), destPos, lastPos(), gValue(),
                p -> world.withinBounds(p) && !(world.getOccupant(p).isPresent()),
                (p1, p2) -> PathingStrategy.CARDINAL_NEIGHBORS.apply(p1).anyMatch(p -> p.equals(p2)),
                PathingStrategy.DIAGONAL_CARDINAL_NEIGHBORS);

        if (points.size() > 0)
            return getDirection(points.get(0));
        else
            return position();
    }

    private Point getDirection(Point dest) {
        String dir;
        if (dest.x > position().x) dir = RIGHT_DIR;
        else if (dest.x < position().x) dir = LEFT_DIR;
        else if (dest.y <position().y) dir = UP_DIR;
        else dir = DOWN_DIR;

        if (dir != direction) {
            direction = dir;
            setImageIndex(0);
            nextImage();
        }
        return dest;
    }
}
