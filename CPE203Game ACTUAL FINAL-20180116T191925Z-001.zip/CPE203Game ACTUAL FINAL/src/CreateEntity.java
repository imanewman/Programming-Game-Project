import processing.core.PImage;

import java.util.List;

public class CreateEntity {
    public static Entity createSinkhole(String id, Point position, int actionPeriod,
                                        List<PImage> images, int source, Viewport viewport) {
        return new Sinkhole(id, position, images, actionPeriod, source, viewport);
    }

    public static Entity createAlien(String id, Point position, int actionPeriod,
                                     int animationPeriod, List<PImage> images, Viewport viewport) {
        return new Alien(id, position, actionPeriod, animationPeriod, images, viewport);
    }

    public static Entity createRandomCreature(String id, Point position, int actionPeriod,
                                              int animationPeriod, List<PImage> images, int resourceLimit) {
        return new RandomCreature(id, position, actionPeriod, animationPeriod, images, resourceLimit);
    }

    public static Entity createLawnmower(String id, Point position, int actionPeriod,
                                              int animationPeriod, List<PImage> images) {
        return new Lawnmower(id, position, actionPeriod, animationPeriod, images);
    }

    public static Entity createBlacksmith(String id, Point position,
                                          List<PImage> images) {
        return new Blacksmith(id, position, images);
    }

    public static Entity createMinerFull(String id, int resourceLimit,
                                         Point position, int actionPeriod, int animationPeriod,
                                         List<PImage> images) {
        return new MinerFull(id, position, images,
                resourceLimit, actionPeriod, animationPeriod);
    }

    public static Entity createMinerNotFull(String id, int resourceLimit,
                                            Point position, int actionPeriod, int animationPeriod,
                                            List<PImage> images) {
        return new MinerNotFull(id, position, images,
                resourceLimit, actionPeriod, animationPeriod);
    }

    public static Entity createObstacle(String id, Point position,
                                        List<PImage> images) {
        return new Obstacle(id, position, images);
    }

    public static Entity createOre(String id, Point position, int actionPeriod,
                                   List<PImage> images) {
        return new Ore(id, position, images, actionPeriod);
    }

    public static Entity createOreBlob(String id, Point position,
                                       int actionPeriod, int animationPeriod, List<PImage> images) {
        return new OreBlob(id, position, images, actionPeriod, animationPeriod);
    }

    public static Entity createQuake(Point position, List<PImage> images) {
        return new Quake(Quake.QUAKE_ID, position, images,
                Quake.QUAKE_ACTION_PERIOD, Quake.QUAKE_ANIMATION_PERIOD);
    }

    public static Entity createVein(String id, Point position, int actionPeriod,
                                    List<PImage> images) {
        return new Vein(id, position, images, actionPeriod);
    }
}
