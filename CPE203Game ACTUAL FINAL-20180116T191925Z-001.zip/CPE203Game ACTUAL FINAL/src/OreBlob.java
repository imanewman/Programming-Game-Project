  import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class OreBlob extends AbsMovable {
    public static final String BLOB_KEY = "blob";
    public static final String BLOB_ID_SUFFIX = " -- blob";
    public static final int BLOB_PERIOD_SCALE = 4;
    public static final int BLOB_ANIMATION_MIN = 50;
    public static final int BLOB_ANIMATION_MAX = 150;

    public OreBlob(String id, Point position, List<PImage> images,
                   int actionPeriod, int animationPeriod) {
        super(id, position, images, 0, actionPeriod, animationPeriod, new AStarPathingStrategy());
    }

    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Entity> blobTarget = world.findNearest(position(), Vein.class);
        long nextPeriod = actionPeriod();

        if (blobTarget.isPresent()) {
            Point tgtPos = blobTarget.get().position();

            if (moveTo(world, blobTarget.get(), scheduler)) {
                Entity quake = CreateEntity.createQuake(tgtPos,
                        imageStore.getImageList(Quake.QUAKE_KEY));

                world.addEntity(quake);
                nextPeriod += actionPeriod();
                ((Quake) quake).scheduleActions(scheduler, world, imageStore);
            }
        }

        scheduler.scheduleEvent(this,
                createActivityAction(world, imageStore),
                nextPeriod);
    }

    public Point nextPos(WorldModel world, Point destPos) {
        if (!destPos.equals(destination())) {
            setDestination(destPos);
            resetGValue();
            resetLastPos();
        }
        List<Point> points = strategy().computePath(position(), destPos, lastPos(), gValue(),
                p -> world.withinBounds(p) && (world.getOccupant(p).isPresent()) && !(world.getOccupant(p).getClass().equals(Ore.class)),
                (p1, p2) -> PathingStrategy.CARDINAL_NEIGHBORS.apply(p1).anyMatch(p -> p.equals(p2)),
                PathingStrategy.DIAGONAL_CARDINAL_NEIGHBORS);

        if (points.size() > 0)
            return points.get(0);
        else
            return position();
    }

    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        if (position().adjacent(target.position())) {
            world.removeEntity(target);
            scheduler.unscheduleAllEvents(target);
            resetGValue();
            return true;
        } else return super.moveTo(world, target, scheduler);
    }

    public <R> R accept(EntityVisitor<R> visitor) { return visitor.visit(this); }
}
