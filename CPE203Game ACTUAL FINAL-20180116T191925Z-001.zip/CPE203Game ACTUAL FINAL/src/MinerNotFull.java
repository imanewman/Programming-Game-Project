import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class MinerNotFull extends AbsMiner implements Miner {
    public MinerNotFull(String id, Point position, List<PImage> images, int resourceLimit,
                     int actionPeriod, int animationPeriod) {
        super(id, position, images, 0, actionPeriod, animationPeriod, resourceLimit, 0);
    }

    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Entity> notFullTarget = world.findNearest(position(), Ore.class);

        if (!notFullTarget.isPresent() ||
                !moveTo(world, notFullTarget.get(), scheduler) ||
                !transform(world, scheduler, imageStore)) {
            scheduler.scheduleEvent(this,
                    createActivityAction(world, imageStore), actionPeriod());
        }
    }

    public boolean transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore) {
        if (resourceCount() >= resourceLimit()) {
            Entity miner = CreateEntity.createMinerFull(id(), resourceLimit(),
                    position(), actionPeriod(), animationPeriod(),
                    images());

            world.removeEntity(this);
            scheduler.unscheduleAllEvents(this);

            world.addEntity(miner);
            ((MinerFull)miner).scheduleActions(scheduler, world, imageStore);

            return true;
        }

        return false;
    }

    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        if (position().adjacent(target.position())) {
            addToResourceCount(1);
            world.removeEntity(target);
            scheduler.unscheduleAllEvents(target);
            return true;
        } else return super.moveTo(world, target, scheduler);
    }

    public <R> R accept(EntityVisitor<R> visitor) { return visitor.visit(this); }
}
