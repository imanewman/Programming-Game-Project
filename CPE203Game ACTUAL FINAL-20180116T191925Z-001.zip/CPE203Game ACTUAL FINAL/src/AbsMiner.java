import processing.core.PImage;

import java.util.List;

public abstract class AbsMiner extends AbsMovable implements Miner {
    public static final String MINER_KEY = "miner";
    public static final int MINER_NUM_PROPERTIES = 7;
    public static final int MINER_ID = 1;
    public static final int MINER_COL = 2;
    public static final int MINER_ROW = 3;
    public static final int MINER_LIMIT = 4;
    public static final int MINER_ACTION_PERIOD = 5;
    public static final int MINER_ANIMATION_PERIOD = 6;

    private int resourceLimit;
    private int resourceCount;

    public AbsMiner(String id, Point position, List<PImage> images, int imageIndex,
                    int actionPeriod, int animationPeriod, int resourceLimit, int resourceCount) {
        super(id, position, images, imageIndex, actionPeriod, animationPeriod, new AStarPathingStrategy());
        this.resourceLimit = resourceLimit;
        this.resourceCount = resourceCount;
    }

    public int resourceLimit() { return resourceLimit; }

    public int resourceCount() { return resourceCount; }

    public void addToResourceCount(int x) { resourceCount += 1; }

    public Point nextPos(WorldModel world, Point destPos) {
        if (!destPos.equals(destination())) {
            setDestination(destPos);
            resetGValue();
            resetLastPos();
        }
        List<Point> points = strategy().computePath(position(), destPos, lastPos(), gValue(),
                p -> world.withinBounds(p) &&  !(world.getOccupant(p).isPresent()),
                (p1, p2) -> PathingStrategy.CARDINAL_NEIGHBORS.apply(p1).anyMatch(p -> p.equals(p2)),
                PathingStrategy.DIAGONAL_CARDINAL_NEIGHBORS);

        if (points.size() > 0)
            return points.get(0);
        else
            return position();
    }

    public static boolean parse(String[] properties, WorldModel world, ImageStore imageStore) {
        if (properties.length == MINER_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(properties[MINER_COL]),
                    Integer.parseInt(properties[MINER_ROW]));
            Entity entity = CreateEntity.createMinerNotFull(properties[MINER_ID],
                    Integer.parseInt(properties[MINER_LIMIT]),
                    pt,
                    Integer.parseInt(properties[MINER_ACTION_PERIOD]),
                    Integer.parseInt(properties[MINER_ANIMATION_PERIOD]),
                    imageStore.getImageList(MINER_KEY));
            world.tryAddEntity(entity);
        }

        return properties.length == MINER_NUM_PROPERTIES;
    }

}
