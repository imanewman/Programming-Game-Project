public interface Miner extends Movable {
    public boolean transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore);
}
