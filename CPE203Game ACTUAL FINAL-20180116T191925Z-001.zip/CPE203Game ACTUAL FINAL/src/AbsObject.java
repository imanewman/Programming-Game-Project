import processing.core.PImage;

import java.util.List;

public abstract class AbsObject {
    private String id;
    private List<PImage> images;
    private int imageIndex;

    public AbsObject(String id, List<PImage> images, int imageIndex)
    {
        this.id = id;
        this.images = images;
        this.imageIndex = imageIndex;
    }

    public PImage getCurrentImage()
    {
        return images.get(imageIndex);
    }

    public List<PImage> images() { return images; }

    public int imageIndex() { return imageIndex; }

    public void setImageIndex(int i) { imageIndex = i; }

    public String id() { return id; }
}
