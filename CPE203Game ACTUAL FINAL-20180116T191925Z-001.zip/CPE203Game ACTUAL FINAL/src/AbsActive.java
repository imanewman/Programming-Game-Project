import processing.core.PImage;

import java.util.List;

public abstract class AbsActive extends AbsEntity implements Active{
    private int actionPeriod;

    public AbsActive(String id, Point position,
                     List<PImage> images, int imageIndex, int actionPeriod) {
        super(id, position, images, imageIndex);
        this.actionPeriod = actionPeriod;
    }

    public int actionPeriod() { return actionPeriod; }

    public void nextImage() { setImageIndex((imageIndex() + 1) % images().size()); }

    public Action createActivityAction(WorldModel world, ImageStore imageStore) {
        return new Activity(this, world, imageStore, 0);
    }

    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this, createActivityAction(world, imageStore), actionPeriod());
    }
}
