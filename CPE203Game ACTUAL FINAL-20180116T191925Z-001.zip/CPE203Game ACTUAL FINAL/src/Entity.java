import java.util.List;
import java.util.Optional;
import java.util.Random;

import processing.core.PImage;

public interface Entity {
    public PImage getCurrentImage();
    public Point position();
    public void setPosition(Point pos);
    public abstract <R> R accept(EntityVisitor<R> visitor);

    public static Optional<Entity> nearestEntity(List<Entity> entities, Point pos) {
        if (entities.isEmpty()) {
            return Optional.empty();
        } else {
            Entity nearest = entities.get(0);
            int nearestDistance = nearest.position().distanceSquared(pos);

            for (Entity other : entities) {
                int otherDistance = other.position().distanceSquared(pos);

                if (otherDistance < nearestDistance) {
                    nearest = other;
                    nearestDistance = otherDistance;
                }
            }

            return Optional.of(nearest);
        }
    }
}

