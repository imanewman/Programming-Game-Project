import processing.core.PImage;

import java.util.*;
import java.util.function.BiConsumer;

public class Sinkhole extends AbsActive {
    public static final String SINKHOLE_ID = "sinkhole";
    public static final int SINKHOLE_ACTION_PERIOD = 4;

    private final int MAX_SIZE = 3;

    private int source; //0 is eminating sinkholes, 1 is the source sinkhole, 2 is the source when shaking
    private Viewport viewport;
    private int shakeIdx;
    private int size;

    public Sinkhole(String id, Point position,
                    List<PImage> images,  int actionPeriod, int source, Viewport viewport) {
        super(id, position, images, 0, actionPeriod);
        this.source = source;
        this.viewport = viewport;
        shakeIdx = 0;
    }

    public void nextImage() {
        if (imageIndex() < 2)
            setImageIndex((imageIndex() + 1));
    }

    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        long nextPeriod = actionPeriod() * 2;

        if (source == 1) {
            size = ((int) (Math.random() * 10) % MAX_SIZE) + 1;
            Map<Integer, List<Point>> rings = getRings(size);

            BiConsumer<Integer, List<Point>> propagateSinkhole = (num, pts) -> {
                Entity child;
                double rand;

                for (Point p : pts) {
                    rand = Math.random() * 10.0;
                    if (world.getOccupant(p).isPresent()) {
                        Entity target = world.getOccupant(p).get();
                        world.removeEntity(target);
                        scheduler.unscheduleAllEvents(target);
                    }


                    if (num == size && size > 1 && rand > 9.2) {
                        child = CreateEntity.createAlien(Alien.ALIEN_ID, p,
                                Alien.ALIEN_ACTION_PERIOD, Alien.ALIEN_ANIMATION_PERIOD,
                                imageStore.images().get(Alien.ALIEN_ID), viewport);
                    } else {
                        child = CreateEntity.createSinkhole(id(), p, actionPeriod(),
                                images(), 0, viewport);
                    }

                    world.addEntity(child);
                    ((Active) child).scheduleActions(scheduler, world, imageStore);
                }
            };

            rings.forEach(propagateSinkhole);
            source = 2;
        }

        if (shakeIdx < 2 + size * 2) {
            if (source == 2)
                shake();

            nextImage();
            scheduler.scheduleEvent(this,
                    createActivityAction(world, imageStore),
                    nextPeriod);
        }
    }

    public void shake() {
        int[][] hShake = {{-1, 1, 1, -1},
                {-2, 2, 2, -2, -2, 2},
                {-3, 3, 3, -3, -3, 3, 3, -3}
        };

        viewport.shift(viewport.col() + hShake[size - 1][shakeIdx++ % hShake[size - 1].length], viewport.row());
    }

    public Map<Integer, List<Point>> getRings(int size) {
        Map<Integer, List<Point>> rings = new HashMap<Integer, List<Point>>();
        for (int i = 1; i <= size; i++) {
            rings.put(i, ring(i));
        }

        return rings;
    }

    private List<Point> ring(int size) {
        List<Point> pts = new ArrayList<>();

        switch (size) {
            default:
            case 3:
                pts.add(new Point(position().x - 2, position().y + 2));
                pts.add(new Point(position().x - 2, position().y + 3));
                pts.add(new Point(position().x - 1, position().y + 3));
                pts.add(new Point(position().x, position().y + 3));
                pts.add(new Point(position().x + 1, position().y + 3));
                pts.add(new Point(position().x + 2, position().y + 3));

                pts.add(new Point(position().x + 2, position().y + 2));
                pts.add(new Point(position().x + 3, position().y + 2));
                pts.add(new Point(position().x + 3, position().y + 1));
                pts.add(new Point(position().x + 3, position().y));
                pts.add(new Point(position().x + 3, position().y - 1));
                pts.add(new Point(position().x + 3, position().y - 2));

                pts.add(new Point(position().x + 2, position().y - 2));
                pts.add(new Point(position().x - 2, position().y - 3));
                pts.add(new Point(position().x - 1, position().y - 3));
                pts.add(new Point(position().x, position().y - 3));
                pts.add(new Point(position().x + 1, position().y - 3));
                pts.add(new Point(position().x + 2, position().y - 3));

                pts.add(new Point(position().x - 2, position().y - 2));
                pts.add(new Point(position().x - 3, position().y + 2));
                pts.add(new Point(position().x - 3, position().y + 1));
                pts.add(new Point(position().x - 3, position().y));
                pts.add(new Point(position().x - 3, position().y - 1));
                pts.add(new Point(position().x - 3, position().y - 2));

                pts = randSave(pts, size);

                return pts;
            case 2:
                pts.add(new Point(position().x - 1, position().y + 2));
                pts.add(new Point(position().x, position().y + 2));
                pts.add(new Point(position().x + 1, position().y + 2));

                pts.add(new Point(position().x + 2, position().y + 1));
                pts.add(new Point(position().x + 2, position().y));
                pts.add(new Point(position().x + 2, position().y - 1));

                pts.add(new Point(position().x - 1, position().y - 2));
                pts.add(new Point(position().x, position().y - 2));
                pts.add(new Point(position().x + 1, position().y - 2));

                pts.add(new Point(position().x - 2, position().y + 1));
                pts.add(new Point(position().x - 2, position().y));
                pts.add(new Point(position().x - 2, position().y - 1));

                pts.add(new Point(position().x + 1, position().y + 1));
                pts.add(new Point(position().x - 1, position().y + 1));
                pts.add(new Point(position().x + 1, position().y - 1));
                pts.add(new Point(position().x - 1, position().y - 1));

                pts = randSave(pts, size);

                return pts;
            case 1:
                pts.add(new Point(position().x + 1, position().y));
                pts.add(new Point(position().x - 1, position().y));
                pts.add(new Point(position().x, position().y + 1));
                pts.add(new Point(position().x, position().y - 1));

                return pts;
        }
    }

    private List<Point> randSave(List<Point> pts, int size) {
        if (this.size == size) {
            int rand = (int) (Math.random() * 100.0);

            if (rand > 50) ;
            pts.remove(rand % pts.size());
            if (rand > 75)
                pts = randSave(pts, size);
        }
        return pts;
    }

    public <R> R accept(EntityVisitor<R> visitor) { return visitor.visit(this); }
}
