public interface Action {
   public void executeAction(EventScheduler scheduler);
}
