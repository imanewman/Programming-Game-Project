import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class Lawnmower extends AbsDirectionable {
    public static final String LAWNMOWER_ID = "lawnmower";
    public static final int LAWNMOWER_ACTION_PERIOD = 700;
    public static final int LAWNMOWER_ANIMATION_PERIOD = 700;

    private final int MAX_LIFESPAN = 30;

    private int lifeSpan;

    public Lawnmower(String id, Point position, int actionPeriod,
                         int animationPeriod, List<PImage> images) {
        super(id, position, actionPeriod, animationPeriod, images);
        lifeSpan = 0;
    }

    public void nextImage() {
        switch(direction()) {
            case LEFT_DIR:
                setImageIndex(3);
                break;
            case DOWN_DIR:
                setImageIndex(0);
                break;
            case RIGHT_DIR:
                setImageIndex(1);
                break;
            case UP_DIR:
                setImageIndex(2);
                break;
        }
    }

    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        long nextPeriod = actionPeriod() * 3;
        Optional<Entity> target = world.findNearest(position(), Sinkhole.class);

        if (target.isPresent()) {
            moveTo(world, target.get(), scheduler);
        }

        if (lifeSpan < MAX_LIFESPAN) {
            lifeSpan++;
            scheduler.scheduleEvent(this,
                    createActivityAction(world, imageStore),
                    nextPeriod);
        } else {
            transform(world, scheduler, imageStore);
        }
    }

    public void transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore) {
        Entity miner = CreateEntity.createMinerNotFull(MINER_ID, MINER_RESOURCE_LIMIT,
                position(), MINER_ACTION_PERIOD, MINER_ANIMATION_PERIOD,
                imageStore.images().get(MINER_ID));

        world.removeEntity(this);
        scheduler.unscheduleAllEvents(this);

        world.addEntity(miner);
        ((Active)miner).scheduleActions(scheduler, world, imageStore);
    }

    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        if (position().adjacent(target.position())) {
            world.removeEntity(target);
            scheduler.unscheduleAllEvents(target);
            resetGValue();
            resetLastPos();
            return true;
        } else return super.moveTo(world, target, scheduler);
    }


    public <R> R accept(EntityVisitor<R> visitor) { return visitor.visit(this); }
}
