import java.util.List;
import processing.core.PImage;

final class Background extends AbsObject
{
   public static final String BGND_KEY = "background";
   private static final int BGND_NUM_PROPERTIES = 4;
   private static final int BGND_ID = 1;
   private static final int BGND_COL = 2;
   private static final int BGND_ROW = 3;

   public Background(String id, List<PImage> images)
   {
      super(id, images, 0);
   }

   public static boolean parse(String[] properties,
                                          WorldModel world, ImageStore imageStore) {
      if (properties.length == Background.BGND_NUM_PROPERTIES) {
         Point pt = new Point(Integer.parseInt(properties[Background.BGND_COL]),
                 Integer.parseInt(properties[Background.BGND_ROW]));
         String id = properties[Background.BGND_ID];
         world.setBackground(pt,
                 new Background(id, imageStore.getImageList(id)));
      }

      return properties.length == Background.BGND_NUM_PROPERTIES;
   }
}
