public interface Active extends Entity {
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore);
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler);
    public Action createActivityAction(WorldModel world, ImageStore imageStore);
    public void nextImage();
}
