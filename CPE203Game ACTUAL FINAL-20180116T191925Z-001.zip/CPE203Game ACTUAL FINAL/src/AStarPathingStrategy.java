import java.util.*;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AStarPathingStrategy implements PathingStrategy {

    public List<Point> computePath(Point start, Point end, final List<Point> last, final int gDist,
                                   Predicate<Point> canPassThrough,
                                   BiPredicate<Point, Point> withinReach,
                                   Function<Point, Stream<Point>> potentialNeighbors)
    {
        //Function<Point, Integer> gDist = pt -> Math.abs(pt.x - start.x) + Math.abs(start.y - end.y);
        Function<Point, Integer> hDist = pt -> Math.abs(pt.x - end.x) + Math.abs(pt.y - end.y);
        Function<Point, Integer> tDist = pt -> /*gDist.apply(pt)*/ gDist + hDist.apply(pt); //the increasing gDist doesnt matter, since the tDist comp would cancel out the increases in gDist
        Function<Point, Stream<Point>> movableNeighbors = pt -> potentialNeighbors.apply(pt)
                .filter(canPassThrough)
                .filter(p -> !(last.contains(p)));
        Comparator<Point> tDistComp = (p1, p2) -> (tDist.apply(p1) - tDist.apply(p2));

        LinkedList<Point> path = new LinkedList<>();
        List<Point> visited = new ArrayList<>();
        //List<Point> positions = new ArrayList<>();
        Point currentPos = start;

        while (!(withinReach.test(currentPos, end)) && path.size() != 15) {
            if (movableNeighbors.apply(currentPos)
                    .filter(pt -> !visited.contains(pt))
                    .count() == 0) { //if there are no neighbors that can be moved to
                if (path.size() == 0) //cant move
                    break;
                else { //go back one step
                    path.removeLast();
                    visited.add(currentPos);
                    if (path.size() == 0)
                        currentPos = start;
                    else
                        currentPos = path.getLast();
                }
            }
            else { //if can move to neighbor
                /*positions.addAll(movableNeighbors.apply(currentPos)
                        .filter(pt -> !visited.contains(pt))
                        .collect(Collectors.toList()));*/

                //find neighbor with minimum f
                Point min = movableNeighbors.apply(currentPos)
                        .filter(pt -> !visited.contains(pt))
                        .min(tDistComp).get();

                path.add(min);
                visited.add(currentPos);
                currentPos = min;
            }
        }

        return path;
    }
}

/*public List<Point> computePath_old(Point start, Point end, Point last, int gDist,
                                   Predicate<Point> canPassThrough,
                                   BiPredicate<Point, Point> withinReach,
                                   Function<Point, Stream<Point>> potentialNeighbors)
    {
        Comparator<Point> hCalc = (p1, p2) -> Math.abs(p1.x - p2.x) + Math.abs(p1.y - p2.y);

        double hMin = potentialNeighbors.apply(start)
                .filter(canPassThrough)
                .filter(pt -> !pt.equals(start) && !pt.equals(end))
                .mapToDouble(pt -> hCalc.compare(pt, end))
                .min()
                .getAsDouble();

        return potentialNeighbors.apply(start)
                .filter(canPassThrough)
                .filter(pt -> !pt.equals(start) && !pt.equals(end))
                .filter(pt -> hCalc.compare(pt, end) <= hMin)
                .limit(1)
                .collect(Collectors.toList());
    }*/
/*
points = strategy.computePath(position(), target.position(),
                p -> world.withinBounds(p),
                (p1, p2) -> PathingStrategy.CARDINAL_NEIGHBORS.apply(p1).anyMatch(p -> p.equals(p2)),
                PathingStrategy.DIAGONAL_CARDINAL_NEIGHBORS);
 */