import processing.core.PImage;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Stream;

public abstract class AbsMovable extends AbsAnimated implements  Movable {
    private PathingStrategy strategy;
    private List<Point> lastPos;
    private Point destination;
    private int gValue;

    public AbsMovable(String id, Point position,
                      List<PImage> images, int imageIndex,
                      int actionPeriod, int animationPeriod,
                      PathingStrategy strategy) {
        super(id, position, images, imageIndex, actionPeriod, animationPeriod);
        this.strategy = strategy;
        lastPos = new LinkedList<>();
        destination = position;
        gValue = 0;
    }

    public PathingStrategy strategy() { return strategy; }

    public List<Point> lastPos() { return lastPos; }

    public void resetLastPos() { lastPos.clear(); }

    public Point destination() { return destination; }

    public void setDestination(Point p) { destination = p; }

    public int gValue() { return gValue; }

    public void resetGValue() { gValue = 0; }

    public void incrGValue() { gValue += 1; }

    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        Point nextPos = nextPos(world, target.position());

        if (!position().equals(nextPos)) {
            Optional<Entity> occupant = world.getOccupant(nextPos);
            if (occupant.isPresent()) {
                scheduler.unscheduleAllEvents(occupant.get());
            }

            incrGValue();
            lastPos.add(position());
            world.moveEntity(this, nextPos);
        }
        return false;
    }

    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        super.scheduleActions(scheduler, world, imageStore);
        scheduler.scheduleEvent(this,
                createAnimationAction(0), animationPeriod());
    }
}
