import java.util.List;

public interface Movable extends Animated {
    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler);
    public Point nextPos(WorldModel world, Point destPos);
    public PathingStrategy strategy();
    public List<Point> lastPos();
    public void resetLastPos();
    public Point destination();
    public void setDestination(Point p);
    public int gValue();
    public void resetGValue();
    public void incrGValue();
}
