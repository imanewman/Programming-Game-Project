import processing.core.PImage;

import java.util.List;
import java.util.Optional;

public class RandomCreature extends AbsDirectionable {
    public static final String RANDOM_CREATURE_ID = "randomCreature";
    public static final int RANDOM_CREATURE_ACTION_PERIOD = 300;
    public static final int RANDOM_CREATURE_ANIMATION_PERIOD = 300;

    private final String RACCOON_ID = "raccoon";
    private final String RAT_ID = "rat";
    private final String SNAKE_ID = "snake";

    private final int MAX_LIFESPAN = 20;

    private String creature;
    private int lifeSpan;
    private int resourceCount;
    private int resourceLimit;

    public RandomCreature(String id, Point position, int actionPeriod, int animationPeriod,
                 List<PImage> images, int resourceLimit) {
        super(id, position, actionPeriod, animationPeriod, images);
        this.resourceLimit = resourceLimit;
        resourceCount = 0;
        lifeSpan = 0;
        creature = getCreature();
        nextImage();
    }

    private String getCreature() {
        int rand = (int)(Math.random() * 8);

        if (rand < 3) return RACCOON_ID;
        else if (rand > 2 && rand < 6) return RAT_ID;
        else return SNAKE_ID;
    }

    public void nextImage() {
        int imageIncr = 0;
        switch(direction()) {
            case LEFT_DIR:
                imageIncr += 2;
            case DOWN_DIR:
                imageIncr += 2;
            case RIGHT_DIR:
                imageIncr += 2;
            case UP_DIR:
                break;
        }

        switch(creature) {
            case RACCOON_ID:
                setImageIndex((imageIndex() + 1) % 2 + imageIncr);
                break;
            case RAT_ID:
                setImageIndex((imageIndex() + 1) % 2 + imageIncr + 8);
                break;
            case SNAKE_ID:
                setImageIndex((imageIndex() + 1) % 2 + imageIncr + 16);
                break;
        }
    }

    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Entity> target = world.findNearest(position(), Ore.class);

        if (!target.isPresent() ||
                !moveTo(world, target.get(), scheduler) ||
                !transform(world, scheduler, imageStore, MinerFull.class)) {
            scheduler.scheduleEvent(this,
                    createActivityAction(world, imageStore), actionPeriod());
        }

        if (lifeSpan < MAX_LIFESPAN)
            lifeSpan++;
        else
            transform(world, scheduler, imageStore, Lawnmower.class);
    }

    public boolean transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore, Class entityClass) {
        Entity entity;

        if (entityClass.equals(MinerFull.class)) {
            if (resourceCount >= resourceLimit) {
                entity = CreateEntity.createMinerNotFull(MINER_ID, MINER_RESOURCE_LIMIT,
                        position(), MINER_ACTION_PERIOD, MINER_ANIMATION_PERIOD,
                        imageStore.images().get("miner"));
            } else
                return false;
        } else if (entityClass.equals(Lawnmower.class)) {
            entity = CreateEntity.createLawnmower(Lawnmower.LAWNMOWER_ID, position(),
                    Lawnmower.LAWNMOWER_ACTION_PERIOD, Lawnmower.LAWNMOWER_ANIMATION_PERIOD,
                    imageStore.images().get(Lawnmower.LAWNMOWER_ID));
        } else
            return false;

        world.removeEntity(this);
        scheduler.unscheduleAllEvents(this);

        world.addEntity(entity);
        ((Active) entity).scheduleActions(scheduler, world, imageStore);

        return true;
    }

    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        if (position().adjacent(target.position())) {
            resourceCount++;
            world.removeEntity(target);
            scheduler.unscheduleAllEvents(target);
            resetGValue();
            resetLastPos();
            return true;
        } else return super.moveTo(world, target, scheduler);
    }

    public <R> R accept(EntityVisitor<R> visitor) { return visitor.visit(this); }
}
