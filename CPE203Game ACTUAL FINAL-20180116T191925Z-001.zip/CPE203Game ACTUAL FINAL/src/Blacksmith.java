import processing.core.PImage;

import java.util.List;

public class Blacksmith extends AbsEntity {
    public static final String SMITH_KEY = "blacksmith";
    private static final int SMITH_NUM_PROPERTIES = 4;
    private static final int SMITH_ID = 1;
    private static final int SMITH_COL = 2;
    private static final int SMITH_ROW = 3;

    public Blacksmith(String id, Point position,
                List<PImage> images) {
        super(id, position, images, 0);
    }

    public <R> R accept(EntityVisitor<R> visitor) { return visitor.visit(this); }

    public static boolean parse(String[] properties, WorldModel world,
                                      ImageStore imageStore) {
        if (properties.length == SMITH_NUM_PROPERTIES) {
            Point pt = new Point(Integer.parseInt(properties[SMITH_COL]),
                    Integer.parseInt(properties[SMITH_ROW]));
            Entity entity = CreateEntity.createBlacksmith(properties[SMITH_ID],
                    pt, imageStore.getImageList(SMITH_KEY));
            world.tryAddEntity(entity);
        }

        return properties.length == SMITH_NUM_PROPERTIES;
    }
}
